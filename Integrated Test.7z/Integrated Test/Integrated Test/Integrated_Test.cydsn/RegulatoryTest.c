/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 * 
 * ========================================
 * This file has the code that enables Regulatory testings
 * for regulations such as FCC,IC,ETSI, KC, MIC, etc. Button 
 * press is needed to switch between various transmit and receive modes
*/
#include <project.h>
#include <stdbool.h>
#include <TwoWire.h>
#include <RegulatoryTest.h>

/*****************************************************************************
* Global Variable Declaration
*****************************************************************************/

DUTStates DUTState = DUT_IDLE;
#ifdef TRICOLOR_LED
LEDColors CurrentColor = LED_OFF;
uint8_t LEDToggleState = 0;
#endif
uint8_t CurrentChannel = 0;
uint8_t ButtonPressed = 0;

static uint32_t BLE_BLELL_RECEIVE_TRIG_CTRL_backup;
static uint32_t BLE_BLELL_COMMAND_REGISTER_backup;
static uint32_t BLE_BLELL_LE_RF_TEST_MODE_backup;
static uint32_t BLE_BLERD_CFG2_backup;
static uint32_t BLE_BLERD_CFGCTRL_backup;
static uint32_t BLE_BLERD_SY_backup;
static bool DTM_test_inprogress = false;
void SetPower(CYBLE_BLESS_PWR_LVL_T power);

/*****************************************************************************
* External Function Prototypes
*****************************************************************************/
/* Direct Test Mode related LL hardware APIs */

extern void llh_program_dtm_tx_test
    (
        /* IN */ UCHAR length,
        /* IN */ UCHAR payload_type,
        /* IN */ UCHAR tx_freq
    );

extern void llh_program_dtm_rx_test(/* IN */ UCHAR rx_freq);

extern UINT16 llh_stop_dtm(void);


/*******************************************************************************
* Function Name: ButtonTriggerISR
********************************************************************************
*
* Summary:
*  Interrupt Service Routine for Button presses. This routine sets a global
* variable that records the interrupt event and disbales the button interrupt.
*
* Parameters:  
*  None
*
* Return: 
*  None 
*  
*******************************************************************************/

CY_ISR(ButtonTriggerISR)
{
    ButtonPressed = 1;
    Button_Trigger_interrupt_Disable();
}

#ifdef TRICOLOR_LED
/*******************************************************************************
* Function Name: SetLEDColor
********************************************************************************
*
* Summary:
*  Sets the LED color of LED3 of BLE Pioneer kit to the value passed in the 
* parameters
*
* Parameters:  
*  LEDColor. Changes the LED color to one of the following colors
* LED_WHITE, //000 - RGB
* LED_CYAN,  //001 - GB
* LED_PINK,  //010 - RB
* LED_BLUE,  //011 - B
* LED_YELLOW, //100 - RG
* LED_GREEN, //101 - G
* LED_RED,   //110 - R
* LED_OFF,   //111 - None
*
* Return: 
*  None 
*  
*******************************************************************************/
void SetLEDColor(LEDColors LEDColor)
{
    uint8 Red_LED, Blue_LED, Green_LED;
    
    if((LEDColor == LED_WHITE) || (LEDColor == LED_RED) 
    || (LEDColor == LED_PINK) || (LEDColor == LED_YELLOW))
    {
        Red_LED = 0;
    }
    else
    {
        Red_LED = 1;
    }
    if((LEDColor == LED_WHITE) || (LEDColor == LED_GREEN) 
    || (LEDColor == LED_CYAN) || (LEDColor == LED_YELLOW))
    {
        Green_LED = 0;
    }
    else
    {
        Green_LED = 1;
    }

    if((LEDColor == LED_WHITE) || (LEDColor == LED_BLUE) 
    || (LEDColor == LED_CYAN) || (LEDColor == LED_PINK))
    {
        Blue_LED = 0;
    }
    else
    {
        Blue_LED = 1;
    }
    Red_LED_Write(Red_LED);
    Green_LED_Write(Green_LED);
    Blue_LED_Write(Blue_LED);
}

/*******************************************************************************
* Function Name: ToggleLED
********************************************************************************
*
* Summary: Toggles the LED state between ON and OFF with LEDColor
* if theToggleCondition is true
* 
*
* Parameters:  
* ToggleCondition   :- A logical expression that evaluates to true or false
* LEDColor          :- LED color for blink
*
* Return: 
*  None 
*  
*******************************************************************************/

void ToggleLED(bool ToggleCondition, char LEDColor)
{
    if(ToggleCondition)
    {
        if(LEDToggleState)
        {
            LEDToggleState = 0;
            SetLEDColor(LED_OFF);
        }
        else
        {
            LEDToggleState = 1;
            SetLEDColor(LEDColor);
        }
        CyDelay(50);
    }
}
#endif
/*******************************************************************************
* Function Name: RegulatoryTestInit
********************************************************************************
*
* Summary:
*  Initialization Routine. Starts the button interrupt, assigns a ISR for the 
* interrupt and turns OFF the LED
*
* Parameters:  
*  None
*
* Return: 
*  None 
*  
*******************************************************************************/


void RegulatoryTestInit(void)
{
    Button_Trigger_interrupt_StartEx(ButtonTriggerISR);
#ifdef TRICOLOR_LED    
    SetLEDColor(LED_OFF);
#endif
    CY_SET_REG32(CYREG_BLE_BLELL_TX_RX_SYNTH_DELAY, 0x1840); 
    SetPower(CYBLE_LL_PWR_LVL_3_DBM);
//    llh_program_dtm_tx_test(0x25, DTM_PKT_TYPE_PRBS9, 39);
}

/*******************************************************************************
* Function Name: SetPower
********************************************************************************
*
* Summary: Sets the transmit power level
* 
*
* Parameters:  
*  power :- Enumerated values support select power levels from -18 dBm to 3 dBm
*
* Return: 
*  None 
*  
*******************************************************************************/

void SetPower(CYBLE_BLESS_PWR_LVL_T power)
{
    CYBLE_BLESS_PWR_IN_DB_T blessPwrAdv;

    blessPwrAdv. bleSsChId = CYBLE_LL_ADV_CH_TYPE; // Select ADV ch grp
    blessPwrAdv. blePwrLevelInDbm  = power;//CYBLE_LL_PWR_LVL_NEG_1_DBM; // -1 dBm

    (void)CyBle_SetTxPowerLevel (&blessPwrAdv); // Check the error code 
    blessPwrAdv. bleSsChId = CYBLE_LL_CONN_CH_TYPE;
    blessPwrAdv. blePwrLevelInDbm  = power;
    (void)CyBle_SetTxPowerLevel (&blessPwrAdv); // Check the error code 
}

/************************************************************************************************
 *
 *
 ************************************************************************************************/
void stop_DTM_tests()
{
    if (DTM_test_inprogress == true)
    {
        CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLERD_DBUS), 0xC992);
        CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLELL_COMMAND_REGISTER),0x48); //setting it to idle
        DTM_test_inprogress = false;
    }
}

/************************************************************************************************
 *
 *
 ************************************************************************************************/
void recover_from_TXC()
{
    CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLERD_SY), BLE_BLERD_SY_backup);
    CyDelayUs(120);
    CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLERD_CFGCTRL), BLE_BLERD_CFGCTRL_backup);
    CyDelayUs(120);
    CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLERD_CFG2), BLE_BLERD_CFG2_backup);
    CyDelayUs(120);
    CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLERD_CFG1), 0xBA40);    
        
    CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLELL_RECEIVE_TRIG_CTRL), BLE_BLELL_RECEIVE_TRIG_CTRL_backup);
    CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLELL_LE_RF_TEST_MODE), BLE_BLELL_LE_RF_TEST_MODE_backup);
    CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLELL_COMMAND_REGISTER), BLE_BLELL_COMMAND_REGISTER_backup);
    CyDelayUs(120);
    DTM_test_inprogress = false;
}

/************************************************************************************************
 *
 *
 ************************************************************************************************/
void transmit_carrier_wave(uint32_t channel, CYBLE_BLESS_PWR_LVL_T power)
{
    uint32_t cfg2, cfgctrl, sy;
    uint16_t frequency;
    stop_DTM_tests();
    SetPower(power);
    frequency = 2402 + channel * 2;
    BLE_BLELL_RECEIVE_TRIG_CTRL_backup = CY_GET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLELL_RECEIVE_TRIG_CTRL));
//    CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLELL_RECEIVE_TRIG_CTRL), 0x9020);   
    BLE_BLELL_LE_RF_TEST_MODE_backup = CY_GET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLELL_LE_RF_TEST_MODE));
//    CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLELL_LE_RF_TEST_MODE), 0xFC00 | channel); 

    CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLERD_DBUS), 0xE000 | frequency);          
    BLE_BLELL_COMMAND_REGISTER_backup = CY_GET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLELL_COMMAND_REGISTER));

    CyDelayUs(120);

    BLE_BLERD_CFG2_backup = CY_GET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLERD_CFG2));
    cfg2 = BLE_BLERD_CFG2_backup | 0x1000;
	cfg2 &= ~0x03FF; 				
    //Set the DAC value
	cfg2 |= 0x0200;	
	    
    BLE_BLERD_CFGCTRL_backup = CY_GET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLERD_CFGCTRL));
	//Enable Test Mode, Use third order PLL
    cfgctrl =  0x8008;	

    BLE_BLERD_SY_backup = CY_GET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLERD_SY));
	sy = BLE_BLERD_SY_backup | 0x4000;	

    CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLERD_CFG2), cfg2);   
    CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLERD_CFGCTRL), cfgctrl); 
    CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLERD_SY),sy);   
//    CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLELL_COMMAND_REGISTER), 0x46);
    CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLERD_CFG1), 0xBB48);    
    DTM_test_inprogress = true;
    
}

/*******************************************************************************
* Function Name: CycleThroughTxRxStates
********************************************************************************
*
* Summary:
* Cycles through the following states and performs corresponding action upon
* a button Press.
*   DUT_IDLE - Idle state. Does nothing
*   DUT_RX_2402 - Receiver is turned ON at RF Channel 0
*   DUT_RX_2440 - Receiver is turned ON at RF Channel 19
*   DUT_RX_2480 - Receiver is turned ON at RF Channel 39
*   DUT_TX_2402 - Transmit packets at RF Channel 0
*   DUT_TX_2440 - Transmit packets at Channel 19
*   DUT_TX_2480 - Transmit packets at Channel 39
*
* Parameters:  
*  None
*
* Return: 
*  None 
*  
*******************************************************************************/

void CycleThroughTxRxStates(void)
{
    //Stop the current DTM task    
    llh_stop_dtm();
    //recover from txc state
    if((DUTState >= DUT_TXC_2402) && (DUTState <= DUT_TXC_2480))
    {
        recover_from_TXC();
    }    
    //switch to the next state    
    if(DUT_TXC_2480 == DUTState)
    {
        DUTState = DUT_IDLE;  
    }
    else
    {
        //Reset BLE
        DUTState++;
    }
    /*Set the LED color and change the perform the function
    appropriate to the state */
    switch(DUTState)
    {
        case DUT_IDLE:
            break;
        
        case DUT_RX_2402:
            //ss used defines for 0, 19 etc. may be you can call LOW, MID or whatever FCC calls
            CurrentChannel = 0;
            llh_program_dtm_rx_test(CurrentChannel);
            break;
            
        case DUT_RX_2440:
            CurrentChannel = 19;
            llh_program_dtm_rx_test(CurrentChannel);
                      
            break;
            
        case DUT_RX_2480:
            CurrentChannel = 39;
            llh_program_dtm_rx_test(CurrentChannel);        
            break;
            
        case DUT_TX_2402:
            CurrentChannel = 0;
            SetPower(TRANSMIT_POWER_LEVEL);
            llh_program_dtm_tx_test(0x25, DTM_PKT_TYPE_PRBS9, CurrentChannel);
            break;
            
        case DUT_TX_2440:
            CurrentChannel = 19;
            SetPower(TRANSMIT_POWER_LEVEL);
            llh_program_dtm_tx_test(0x25, DTM_PKT_TYPE_PRBS9, CurrentChannel);
            break;
            
        case DUT_TX_2480:
            CurrentChannel = 39;
            SetPower(TRANSMIT_POWER_LEVEL);
            llh_program_dtm_tx_test(0x25, DTM_PKT_TYPE_PRBS9, CurrentChannel);
            break;
            
        case DUT_TXC_2402:
            CurrentChannel = 0;
            transmit_carrier_wave(CurrentChannel, TRANSMIT_POWER_LEVEL);
            break;
        case DUT_TXC_2440:
            CurrentChannel = 19;
            transmit_carrier_wave(CurrentChannel, TRANSMIT_POWER_LEVEL);
            break;
        case DUT_TXC_2480:
            CurrentChannel = 39;
            transmit_carrier_wave(CurrentChannel, TRANSMIT_POWER_LEVEL);
            break;
        default:
            DUTState = DUT_IDLE;    
            break;
            
    }
#ifdef TRICOLOR_LED
    switch(DUTState)
    {
        case DUT_IDLE:
            CurrentColor = LED_OFF;
            break;
        case DUT_RX_2402:
            CurrentColor = LED_YELLOW;
            break;
        case DUT_RX_2440:
            CurrentColor = LED_PINK;
            break;
        case DUT_RX_2480:
            CurrentColor = LED_BLUE;
            break;
        case DUT_TX_2402:
            CurrentColor = LED_YELLOW;
            break;
        case DUT_TX_2440:
            CurrentColor = LED_PINK;
            break;
        case DUT_TXC_2402:
            CurrentColor = LED_YELLOW;
            break;
        case DUT_TXC_2440:
            CurrentColor = LED_PINK;
            break;
        case DUT_TXC_2480:
            CurrentColor = LED_BLUE;
            break;
        default:
            break;
        
    }
    SetLEDColor(CurrentColor);
#endif    
}

/*******************************************************************************
* Function Name: CheckButtonPressStatus
********************************************************************************
*
* Summary: Handles debounce for the button press (if button is pressed)
* and returns true is a valid button press is detected.
* 
*
* Parameters:  
* None
*
* Return: 
* true: if button press is confirmed after debounce
* false: if button is not pressed or if the trigger is a bounce
*  
*******************************************************************************/

bool CheckButtonPressStatus(void)
{
    bool Status =  false;
    if(ButtonPressed)
    {
        //Clear the button pressed flag
        ButtonPressed = 0;
        //Delay for debounce
        CyDelay(100);
        Button_Trigger_ClearInterrupt();
        Button_Trigger_interrupt_ClearPending();
        /* Ensure the pin stays low after press
        part of debounce logic */
        if(Button_Trigger_Read())
        {
            Status = true;
        }
        //Enable the button trigger interrupt
        Button_Trigger_interrupt_Enable();
    }
    return Status;
}

/*******************************************************************************
* Function Name: ProcessRegulatoryTestTrigger
********************************************************************************
*
* Summary:
* Handles the Button Trigger, debounce and LED Toggles
*
* Parameters:  
*  None
*
* Return: 
*  None 
*  
*******************************************************************************/

void ProcessRegulatoryTestTrigger(void)
{
    /*Toggle the LEDs for indicating burst transmission; 
    Solid glow for continuous reception*/
#ifdef TRICOLOR_LED    
    ToggleLED((DUTState > DUT_RX_2480) && (DUTState <= DUT_TX_2480), CurrentColor);
#endif    
    if (CheckButtonPressStatus())
    {
        CycleThroughTxRxStates();
    }
}    

/* [] END OF FILE */
