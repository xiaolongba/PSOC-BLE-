/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <stdbool.h>
#include <TwoWire.h>

/*****************************************************************************
* Global Variable Declaration
*****************************************************************************/
volatile bool DTMCmdDetected = false, DTMInvalidCmd = false;
DTM_Cmd_Packet CurrentCmd = {DTM_INVALID, 0, 0, 0};

/*****************************************************************************
* External Function Prototypes
*****************************************************************************/
/* Direct Test Mode related LL hardware APIs */

extern void llh_program_dtm_tx_test
    (
        /* IN */ UCHAR length,
        /* IN */ UCHAR payload_type,
        /* IN */ UCHAR tx_freq
    );

extern void llh_program_dtm_rx_test(/* IN */ UCHAR rx_freq);

extern UINT16 llh_stop_dtm(void);

extern void DtmEventHandler(uint32 event, void * eventparam);


/*******************************************************************************
* Function Name: ISR_2_Wire_Cmd_Decoder
********************************************************************************
*
* Summary:
*  This ISR decodes the incoming 2 wire command
*
* Parameters:  
*  None
*
* Return: 
*  None 
*  
*******************************************************************************/


CY_ISR(ISR_2_Wire_Cmd_Decoder)
{
    static bool checkMSByte = false;
    
    if(UART_2_Wire_CHECK_INTR_RX_MASKED(UART_2_Wire_INTR_RX_NOT_EMPTY))
    {
        uint8 byte = (uint8)UART_2_Wire_SpiUartReadRxData();

        if(checkMSByte)
        {
            CurrentCmd.Payload_Type = byte & PL_TYPE_MASK;
            CurrentCmd.Payload_Len = (byte & PL_LEN_MASK) >> PL_LEN_SHIFT;
            if(PL_LEN_LIMIT > CurrentCmd.Payload_Len)
            {
                /*Both the bytes decoded, reset the decoder state*/
                DTMCmdDetected = true;
            }
            else
            {
                DTMInvalidCmd = true; 
            }
            checkMSByte = false;
        }
        else
        {
            CurrentCmd.Channel = byte & CHNL_FREQ_MASK;
            CurrentCmd.Cmd_Code = (byte & CMD_CODE_MASK) >> CMD_CODE_SHIFT;
            if(CHNL_FREQ_LIMIT > CurrentCmd.Channel)
            {
                /*LSByte detected, Process the MSByte*/
                checkMSByte = true;
            }
            else
            {
                DTMInvalidCmd = true; 
            }
        }

        UART_2_Wire_ClearRxInterruptSource(UART_2_Wire_INTR_RX_NOT_EMPTY);
    }
}


/*******************************************************************************
* Function Name: void TwoWireInit(void)
********************************************************************************
*
* Summary:
*  Initialization Routine. Starts the 2-wire interface and assigns a ISR for the 
* 2-wire interrupt.
*
* Parameters:  
*  None
*
* Return: 
*  None 
*  
*******************************************************************************/

void TwoWireInit(void)
{
    UART_2_Wire_Start();
    UART_2_Wire_SetCustomInterruptHandler(ISR_2_Wire_Cmd_Decoder);
}


/*******************************************************************************
* Function Name: Process2WireCommands
********************************************************************************
*
* Summary:
*  Process the 2-wire commands.
*
* Parameters:  
*  None
*
* Return: 
*  None 
*  
*******************************************************************************/

void Process2WireCommands(void)
{
    uint8 DTM_Event[2] = {0,0};    
    if(DTMCmdDetected)
    {
        /* Process the DTM Command */
        switch(CurrentCmd.Cmd_Code)
        {
            case DTM_RESET:
                CyBle_Stop();
                CyBle_Start(DtmEventHandler);
                /*send the DTM packet status event*/
                DTM_Event[1] = EVT_STATUS_SUCCESS; //SUCCESS
                DTM_Event[0] = STATUS_EVT_CODE; //event code

                UART_2_Wire_SpiUartPutArray(DTM_Event, sizeof(DTM_Event));
                break;

            case DTM_RX_TEST:
                llh_program_dtm_rx_test(CurrentCmd.Channel);
                /*send the DTM packet status event*/
                DTM_Event[1] = EVT_STATUS_SUCCESS; //SUCCESS
                DTM_Event[0] = STATUS_EVT_CODE; //event code

                UART_2_Wire_SpiUartPutArray(DTM_Event, sizeof(DTM_Event));
                break;

            case DTM_TX_TEST:
                llh_program_dtm_tx_test(CurrentCmd.Payload_Len,
                                        CurrentCmd.Payload_Type, CurrentCmd.Channel);
                /*send the DTM packet status event*/
                DTM_Event[1] = EVT_STATUS_SUCCESS; //SUCCESS
                DTM_Event[0] = STATUS_EVT_CODE; //event code

                UART_2_Wire_SpiUartPutArray(DTM_Event, sizeof(DTM_Event));
                break;

            case DTM_END:
                {
                    uint16 value =  llh_stop_dtm();
                    DTM_Event[1u] = (uint8) value;
                    DTM_Event[0u] = (uint8) (value >> 8u);

                    DTM_Event[0] |= REPORT_EVT_MASK; //Set the report event code
                    
                    /*send the DTM packet Report event*/
                    UART_2_Wire_SpiUartPutArray(DTM_Event, sizeof(DTM_Event));
                }
                break;

            default:
                /*Invalid test*/
                /*send the DTM packet status failure event*/
                DTM_Event[1] = EVT_STATUS_FAIL; //FAIL
                DTM_Event[0] = STATUS_EVT_CODE; //event code

                UART_2_Wire_SpiUartPutArray(DTM_Event, sizeof(DTM_Event));
                break;
        }
        DTMCmdDetected = false;
        CurrentCmd.Cmd_Code = DTM_INVALID;
        CurrentCmd.Channel = 0;
        CurrentCmd.Payload_Len = 0;
        CurrentCmd.Payload_Type = 0;
    }
    /*send the DTM packet status failure event, if wrong command is detected*/
    if(DTMInvalidCmd)
    {
        DTMInvalidCmd = false;
        DTM_Event[1] = EVT_STATUS_FAIL; //FAIL
        DTM_Event[0] = STATUS_EVT_CODE; //event code

        UART_2_Wire_SpiUartPutArray(DTM_Event, sizeof(DTM_Event));
    }
}

/* [] END OF FILE */
