/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <TwoWire.h>
#include <RegulatoryTest.h>

/*******************************************************************************
* Function Name: ButtonTriggerISR
********************************************************************************
*
* Summary:
* This function is a call back for BLE events from the stack. 
* We do not need to handle any events in HCI mode.
* So an empty call back function is defined
*
* Parameters:  
*  None
*
* Return: 
*  None 
*  
*******************************************************************************/
void DtmEventHandler(uint32 event, void * eventparam)
{
	(void)event;
	(void)eventparam;
}

int main()
{
    CyGlobalIntEnable;
    
    Blue_LED_Write(0);
    //Start the BLE stack
    CyBle_Start(DtmEventHandler);
    //Initialize TwoWire Interface
    TwoWireInit();
    //Initialize Regulatory test code
    RegulatoryTestInit();
    
    while(1)
    {
        CyBle_ProcessEvents();
        Process2WireCommands();
        ProcessRegulatoryTestTrigger();
    }
}

/* [] END OF FILE */
