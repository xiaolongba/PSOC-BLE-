/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
/****************************************************************************
* MACROS
****************************************************************************/
#define TRANSMIT_POWER_LEVEL CYBLE_LL_PWR_LVL_3_DBM
#define TRICOLOR_LED
/*****************************************************************************
* Type Definitions
*****************************************************************************/

typedef unsigned char          UCHAR;
typedef unsigned int          UINT16;

/*****************************************************************************
* Enumerated Data Definition
*****************************************************************************/

/* DTM states */
typedef enum 
{
    DUT_IDLE,
    DUT_RX_2402,
    DUT_RX_2440,
    DUT_RX_2480,
    DUT_TX_2402,
    DUT_TX_2440,
    DUT_TX_2480,
    DUT_TXC_2402,
    DUT_TXC_2440,
    DUT_TXC_2480,    
}DUTStates;
#ifdef TRICOLOR_LED
/* LED Colors */
typedef enum
{
    LED_WHITE, //000 - BGR
    LED_CYAN,  //001 - BG 
    LED_PINK,  //010 - BR
    LED_BLUE,  //011 - B
    LED_YELLOW, //100 - GR
    LED_GREEN, //101 - G
    LED_RED,   //110 - R
    LED_OFF,   //111 - None
}LEDColors;
#endif
/*****************************************************************************
* Function prototypes
*****************************************************************************/
extern void RegulatoryTestInit(void);
extern void ProcessRegulatoryTestTrigger(void);
/* [] END OF FILE */
