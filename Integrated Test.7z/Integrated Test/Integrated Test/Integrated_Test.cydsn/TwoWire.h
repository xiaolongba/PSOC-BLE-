/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
/*****************************************************************************
* MACRO Definition
*****************************************************************************/    
#include <project.h>

#define EVT_STATUS_SUCCESS 0u
#define EVT_STATUS_FAIL    1u
#define STATUS_EVT_CODE    0u
#define REPORT_EVT_MASK    0x80u

#define CMD_CODE_MASK      (uint8)0xC0u
#define CHNL_FREQ_MASK     (uint8)0x3Fu

#define CMD_CODE_SHIFT     6u
#define CHNL_FREQ_LIMIT    0x28u

/*Packet payload parser macros*/
#define PL_TYPE_MASK       (uint8)0x03u
#define PL_LEN_MASK        (uint8)0xFCu
#define PL_LEN_SHIFT       2u
#define PL_LEN_LIMIT       0x26u



/*****************************************************************************
* Enumerated Data Definition
*****************************************************************************/
/*DTM Command code*/
typedef enum
{
    DTM_RESET = 0,
    DTM_RX_TEST,
    DTM_TX_TEST,
    DTM_END,
    DTM_INVALID,
}DTM_Cmd_Code;

/*DTM Payload type*/
typedef enum
{
    DTM_PKT_TYPE_PRBS9 = 0,
    DTM_PKT_TYPE_11110000,
    DTM_PKT_TYPE_10101010,
    DTM_PKT_TYPE_VENDOR,
}DTM_PKT_PL_TYPE;

/*****************************************************************************
* Data Struct Definition
*****************************************************************************/

/*DTM Command fields*/
typedef struct _DTM_Cmd_Packet
{
    DTM_Cmd_Code Cmd_Code;
    uint8 Channel;
    uint8 Payload_Len;
    DTM_PKT_PL_TYPE Payload_Type;
}DTM_Cmd_Packet;

typedef unsigned char          UCHAR;
typedef unsigned int          UINT16;

/*****************************************************************************
* Function prototypes
*****************************************************************************/
extern void TwoWireInit(void);
extern void Process2WireCommands(void);


/* [] END OF FILE */
