﻿namespace CyBLE_MTK_Application
{
    partial class MTKTestCUSDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.OKButton = new System.Windows.Forms.Button();
            this.CloseButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.NameTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.CMDDelayNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.Param2CheckBox = new System.Windows.Forms.CheckBox();
            this.Param1CheckBox = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Byte20ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte10ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte15ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte5ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte19ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte9ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte14ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte4ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte20CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte10CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte15CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte5CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte17ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte7ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte12ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte2ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte19CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte9CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte14CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte4CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte17CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte7CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte12CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte2CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte18ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte8ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte13ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte3ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte18CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte8CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte13CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte3CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte16ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte6ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte11ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte1ComboBox = new System.Windows.Forms.ComboBox();
            this.Byte16CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte6CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte11CheckBox = new System.Windows.Forms.CheckBox();
            this.Byte1CheckBox = new System.Windows.Forms.CheckBox();
            this.Param2HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Param1HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.CMDHexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte20HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte10HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte15HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte5HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte19HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte9HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte14HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte4HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte17HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte7HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte12HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte2HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte18HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte8HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte13HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte3HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte16HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte6HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte11HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.Byte1HexadecimalTextBox = new HexadecimalTextBoxControl.HexadecimalTextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CMDDelayNumericUpDown)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // OKButton
            // 
            this.OKButton.Location = new System.Drawing.Point(268, 226);
            this.OKButton.Name = "OKButton";
            this.OKButton.Size = new System.Drawing.Size(75, 23);
            this.OKButton.TabIndex = 0;
            this.OKButton.Text = "&OK";
            this.OKButton.UseVisualStyleBackColor = true;
            this.OKButton.Click += new System.EventHandler(this.OKButton_Click);
            // 
            // CloseButton
            // 
            this.CloseButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.CloseButton.Location = new System.Drawing.Point(350, 226);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(75, 23);
            this.CloseButton.TabIndex = 1;
            this.CloseButton.Text = "&Cancel";
            this.CloseButton.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Test Name:";
            // 
            // NameTextBox
            // 
            this.NameTextBox.Location = new System.Drawing.Point(82, 12);
            this.NameTextBox.Name = "NameTextBox";
            this.NameTextBox.Size = new System.Drawing.Size(594, 20);
            this.NameTextBox.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(262, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Command:";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 38);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(668, 183);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.CMDDelayNumericUpDown);
            this.tabPage1.Controls.Add(this.Param2CheckBox);
            this.tabPage1.Controls.Add(this.Param1CheckBox);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.Param2HexadecimalTextBox);
            this.tabPage1.Controls.Add(this.Param1HexadecimalTextBox);
            this.tabPage1.Controls.Add(this.CMDHexadecimalTextBox);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(660, 157);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Command";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // CMDDelayNumericUpDown
            // 
            this.CMDDelayNumericUpDown.Location = new System.Drawing.Point(326, 108);
            this.CMDDelayNumericUpDown.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.CMDDelayNumericUpDown.Name = "CMDDelayNumericUpDown";
            this.CMDDelayNumericUpDown.Size = new System.Drawing.Size(99, 20);
            this.CMDDelayNumericUpDown.TabIndex = 7;
            this.CMDDelayNumericUpDown.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // Param2CheckBox
            // 
            this.Param2CheckBox.AutoSize = true;
            this.Param2CheckBox.Enabled = false;
            this.Param2CheckBox.Location = new System.Drawing.Point(236, 83);
            this.Param2CheckBox.Name = "Param2CheckBox";
            this.Param2CheckBox.Size = new System.Drawing.Size(86, 17);
            this.Param2CheckBox.TabIndex = 6;
            this.Param2CheckBox.Text = "Parameter 2:";
            this.Param2CheckBox.UseVisualStyleBackColor = true;
            this.Param2CheckBox.CheckedChanged += new System.EventHandler(this.Param2CheckBox_CheckedChanged);
            // 
            // Param1CheckBox
            // 
            this.Param1CheckBox.AutoSize = true;
            this.Param1CheckBox.Location = new System.Drawing.Point(236, 57);
            this.Param1CheckBox.Name = "Param1CheckBox";
            this.Param1CheckBox.Size = new System.Drawing.Size(86, 17);
            this.Param1CheckBox.TabIndex = 6;
            this.Param1CheckBox.Text = "Parameter 1:";
            this.Param1CheckBox.UseVisualStyleBackColor = true;
            this.Param1CheckBox.CheckedChanged += new System.EventHandler(this.Param1CheckBox_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(187, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Command result poll delay:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.Byte20HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte10HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte15HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte5HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte19HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte9HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte14HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte4HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte17HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte7HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte12HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte2HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte18HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte8HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte13HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte3HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte16HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte6HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte11HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte1HexadecimalTextBox);
            this.tabPage2.Controls.Add(this.Byte20ComboBox);
            this.tabPage2.Controls.Add(this.Byte10ComboBox);
            this.tabPage2.Controls.Add(this.Byte15ComboBox);
            this.tabPage2.Controls.Add(this.Byte5ComboBox);
            this.tabPage2.Controls.Add(this.Byte19ComboBox);
            this.tabPage2.Controls.Add(this.Byte9ComboBox);
            this.tabPage2.Controls.Add(this.Byte14ComboBox);
            this.tabPage2.Controls.Add(this.Byte4ComboBox);
            this.tabPage2.Controls.Add(this.Byte20CheckBox);
            this.tabPage2.Controls.Add(this.Byte10CheckBox);
            this.tabPage2.Controls.Add(this.Byte15CheckBox);
            this.tabPage2.Controls.Add(this.Byte5CheckBox);
            this.tabPage2.Controls.Add(this.Byte17ComboBox);
            this.tabPage2.Controls.Add(this.Byte7ComboBox);
            this.tabPage2.Controls.Add(this.Byte12ComboBox);
            this.tabPage2.Controls.Add(this.Byte2ComboBox);
            this.tabPage2.Controls.Add(this.Byte19CheckBox);
            this.tabPage2.Controls.Add(this.Byte9CheckBox);
            this.tabPage2.Controls.Add(this.Byte14CheckBox);
            this.tabPage2.Controls.Add(this.Byte4CheckBox);
            this.tabPage2.Controls.Add(this.Byte17CheckBox);
            this.tabPage2.Controls.Add(this.Byte7CheckBox);
            this.tabPage2.Controls.Add(this.Byte12CheckBox);
            this.tabPage2.Controls.Add(this.Byte2CheckBox);
            this.tabPage2.Controls.Add(this.Byte18ComboBox);
            this.tabPage2.Controls.Add(this.Byte8ComboBox);
            this.tabPage2.Controls.Add(this.Byte13ComboBox);
            this.tabPage2.Controls.Add(this.Byte3ComboBox);
            this.tabPage2.Controls.Add(this.Byte18CheckBox);
            this.tabPage2.Controls.Add(this.Byte8CheckBox);
            this.tabPage2.Controls.Add(this.Byte13CheckBox);
            this.tabPage2.Controls.Add(this.Byte3CheckBox);
            this.tabPage2.Controls.Add(this.Byte16ComboBox);
            this.tabPage2.Controls.Add(this.Byte6ComboBox);
            this.tabPage2.Controls.Add(this.Byte11ComboBox);
            this.tabPage2.Controls.Add(this.Byte1ComboBox);
            this.tabPage2.Controls.Add(this.Byte16CheckBox);
            this.tabPage2.Controls.Add(this.Byte6CheckBox);
            this.tabPage2.Controls.Add(this.Byte11CheckBox);
            this.tabPage2.Controls.Add(this.Byte1CheckBox);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(660, 157);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Command Result";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // Byte20ComboBox
            // 
            this.Byte20ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte20ComboBox.Enabled = false;
            this.Byte20ComboBox.FormattingEnabled = true;
            this.Byte20ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte20ComboBox.Location = new System.Drawing.Point(571, 122);
            this.Byte20ComboBox.Name = "Byte20ComboBox";
            this.Byte20ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte20ComboBox.TabIndex = 1;
            // 
            // Byte10ComboBox
            // 
            this.Byte10ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte10ComboBox.Enabled = false;
            this.Byte10ComboBox.FormattingEnabled = true;
            this.Byte10ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte10ComboBox.Location = new System.Drawing.Point(238, 122);
            this.Byte10ComboBox.Name = "Byte10ComboBox";
            this.Byte10ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte10ComboBox.TabIndex = 1;
            // 
            // Byte15ComboBox
            // 
            this.Byte15ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte15ComboBox.Enabled = false;
            this.Byte15ComboBox.FormattingEnabled = true;
            this.Byte15ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte15ComboBox.Location = new System.Drawing.Point(404, 122);
            this.Byte15ComboBox.Name = "Byte15ComboBox";
            this.Byte15ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte15ComboBox.TabIndex = 1;
            // 
            // Byte5ComboBox
            // 
            this.Byte5ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte5ComboBox.Enabled = false;
            this.Byte5ComboBox.FormattingEnabled = true;
            this.Byte5ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte5ComboBox.Location = new System.Drawing.Point(71, 122);
            this.Byte5ComboBox.Name = "Byte5ComboBox";
            this.Byte5ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte5ComboBox.TabIndex = 1;
            // 
            // Byte19ComboBox
            // 
            this.Byte19ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte19ComboBox.Enabled = false;
            this.Byte19ComboBox.FormattingEnabled = true;
            this.Byte19ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte19ComboBox.Location = new System.Drawing.Point(571, 95);
            this.Byte19ComboBox.Name = "Byte19ComboBox";
            this.Byte19ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte19ComboBox.TabIndex = 1;
            // 
            // Byte9ComboBox
            // 
            this.Byte9ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte9ComboBox.Enabled = false;
            this.Byte9ComboBox.FormattingEnabled = true;
            this.Byte9ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte9ComboBox.Location = new System.Drawing.Point(238, 95);
            this.Byte9ComboBox.Name = "Byte9ComboBox";
            this.Byte9ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte9ComboBox.TabIndex = 1;
            // 
            // Byte14ComboBox
            // 
            this.Byte14ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte14ComboBox.Enabled = false;
            this.Byte14ComboBox.FormattingEnabled = true;
            this.Byte14ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte14ComboBox.Location = new System.Drawing.Point(404, 95);
            this.Byte14ComboBox.Name = "Byte14ComboBox";
            this.Byte14ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte14ComboBox.TabIndex = 1;
            // 
            // Byte4ComboBox
            // 
            this.Byte4ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte4ComboBox.Enabled = false;
            this.Byte4ComboBox.FormattingEnabled = true;
            this.Byte4ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte4ComboBox.Location = new System.Drawing.Point(71, 95);
            this.Byte4ComboBox.Name = "Byte4ComboBox";
            this.Byte4ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte4ComboBox.TabIndex = 1;
            // 
            // Byte20CheckBox
            // 
            this.Byte20CheckBox.AutoSize = true;
            this.Byte20CheckBox.Enabled = false;
            this.Byte20CheckBox.Location = new System.Drawing.Point(506, 124);
            this.Byte20CheckBox.Name = "Byte20CheckBox";
            this.Byte20CheckBox.Size = new System.Drawing.Size(66, 17);
            this.Byte20CheckBox.TabIndex = 0;
            this.Byte20CheckBox.Text = "Byte#20";
            this.Byte20CheckBox.UseVisualStyleBackColor = true;
            this.Byte20CheckBox.CheckedChanged += new System.EventHandler(this.Byte20CheckBox_CheckedChanged);
            // 
            // Byte10CheckBox
            // 
            this.Byte10CheckBox.AutoSize = true;
            this.Byte10CheckBox.Enabled = false;
            this.Byte10CheckBox.Location = new System.Drawing.Point(173, 124);
            this.Byte10CheckBox.Name = "Byte10CheckBox";
            this.Byte10CheckBox.Size = new System.Drawing.Size(66, 17);
            this.Byte10CheckBox.TabIndex = 0;
            this.Byte10CheckBox.Text = "Byte#10";
            this.Byte10CheckBox.UseVisualStyleBackColor = true;
            this.Byte10CheckBox.CheckedChanged += new System.EventHandler(this.Byte10CheckBox_CheckedChanged);
            // 
            // Byte15CheckBox
            // 
            this.Byte15CheckBox.AutoSize = true;
            this.Byte15CheckBox.Enabled = false;
            this.Byte15CheckBox.Location = new System.Drawing.Point(339, 124);
            this.Byte15CheckBox.Name = "Byte15CheckBox";
            this.Byte15CheckBox.Size = new System.Drawing.Size(66, 17);
            this.Byte15CheckBox.TabIndex = 0;
            this.Byte15CheckBox.Text = "Byte#15";
            this.Byte15CheckBox.UseVisualStyleBackColor = true;
            this.Byte15CheckBox.CheckedChanged += new System.EventHandler(this.Byte15CheckBox_CheckedChanged);
            // 
            // Byte5CheckBox
            // 
            this.Byte5CheckBox.AutoSize = true;
            this.Byte5CheckBox.Enabled = false;
            this.Byte5CheckBox.Location = new System.Drawing.Point(6, 124);
            this.Byte5CheckBox.Name = "Byte5CheckBox";
            this.Byte5CheckBox.Size = new System.Drawing.Size(60, 17);
            this.Byte5CheckBox.TabIndex = 0;
            this.Byte5CheckBox.Text = "Byte#5";
            this.Byte5CheckBox.UseVisualStyleBackColor = true;
            this.Byte5CheckBox.CheckedChanged += new System.EventHandler(this.Byte5CheckBox_CheckedChanged);
            // 
            // Byte17ComboBox
            // 
            this.Byte17ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte17ComboBox.Enabled = false;
            this.Byte17ComboBox.FormattingEnabled = true;
            this.Byte17ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte17ComboBox.Location = new System.Drawing.Point(571, 41);
            this.Byte17ComboBox.Name = "Byte17ComboBox";
            this.Byte17ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte17ComboBox.TabIndex = 1;
            // 
            // Byte7ComboBox
            // 
            this.Byte7ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte7ComboBox.Enabled = false;
            this.Byte7ComboBox.FormattingEnabled = true;
            this.Byte7ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte7ComboBox.Location = new System.Drawing.Point(238, 41);
            this.Byte7ComboBox.Name = "Byte7ComboBox";
            this.Byte7ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte7ComboBox.TabIndex = 1;
            // 
            // Byte12ComboBox
            // 
            this.Byte12ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte12ComboBox.Enabled = false;
            this.Byte12ComboBox.FormattingEnabled = true;
            this.Byte12ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte12ComboBox.Location = new System.Drawing.Point(404, 41);
            this.Byte12ComboBox.Name = "Byte12ComboBox";
            this.Byte12ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte12ComboBox.TabIndex = 1;
            // 
            // Byte2ComboBox
            // 
            this.Byte2ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte2ComboBox.Enabled = false;
            this.Byte2ComboBox.FormattingEnabled = true;
            this.Byte2ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte2ComboBox.Location = new System.Drawing.Point(71, 41);
            this.Byte2ComboBox.Name = "Byte2ComboBox";
            this.Byte2ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte2ComboBox.TabIndex = 1;
            // 
            // Byte19CheckBox
            // 
            this.Byte19CheckBox.AutoSize = true;
            this.Byte19CheckBox.Enabled = false;
            this.Byte19CheckBox.Location = new System.Drawing.Point(506, 97);
            this.Byte19CheckBox.Name = "Byte19CheckBox";
            this.Byte19CheckBox.Size = new System.Drawing.Size(66, 17);
            this.Byte19CheckBox.TabIndex = 0;
            this.Byte19CheckBox.Text = "Byte#19";
            this.Byte19CheckBox.UseVisualStyleBackColor = true;
            this.Byte19CheckBox.CheckedChanged += new System.EventHandler(this.Byte19CheckBox_CheckedChanged);
            // 
            // Byte9CheckBox
            // 
            this.Byte9CheckBox.AutoSize = true;
            this.Byte9CheckBox.Enabled = false;
            this.Byte9CheckBox.Location = new System.Drawing.Point(173, 97);
            this.Byte9CheckBox.Name = "Byte9CheckBox";
            this.Byte9CheckBox.Size = new System.Drawing.Size(60, 17);
            this.Byte9CheckBox.TabIndex = 0;
            this.Byte9CheckBox.Text = "Byte#9";
            this.Byte9CheckBox.UseVisualStyleBackColor = true;
            this.Byte9CheckBox.CheckedChanged += new System.EventHandler(this.Byte9CheckBox_CheckedChanged);
            // 
            // Byte14CheckBox
            // 
            this.Byte14CheckBox.AutoSize = true;
            this.Byte14CheckBox.Enabled = false;
            this.Byte14CheckBox.Location = new System.Drawing.Point(339, 97);
            this.Byte14CheckBox.Name = "Byte14CheckBox";
            this.Byte14CheckBox.Size = new System.Drawing.Size(66, 17);
            this.Byte14CheckBox.TabIndex = 0;
            this.Byte14CheckBox.Text = "Byte#14";
            this.Byte14CheckBox.UseVisualStyleBackColor = true;
            this.Byte14CheckBox.CheckedChanged += new System.EventHandler(this.Byte14CheckBox_CheckedChanged);
            // 
            // Byte4CheckBox
            // 
            this.Byte4CheckBox.AutoSize = true;
            this.Byte4CheckBox.Enabled = false;
            this.Byte4CheckBox.Location = new System.Drawing.Point(6, 97);
            this.Byte4CheckBox.Name = "Byte4CheckBox";
            this.Byte4CheckBox.Size = new System.Drawing.Size(60, 17);
            this.Byte4CheckBox.TabIndex = 0;
            this.Byte4CheckBox.Text = "Byte#4";
            this.Byte4CheckBox.UseVisualStyleBackColor = true;
            this.Byte4CheckBox.CheckedChanged += new System.EventHandler(this.Byte4CheckBox_CheckedChanged);
            // 
            // Byte17CheckBox
            // 
            this.Byte17CheckBox.AutoSize = true;
            this.Byte17CheckBox.Enabled = false;
            this.Byte17CheckBox.Location = new System.Drawing.Point(506, 43);
            this.Byte17CheckBox.Name = "Byte17CheckBox";
            this.Byte17CheckBox.Size = new System.Drawing.Size(66, 17);
            this.Byte17CheckBox.TabIndex = 0;
            this.Byte17CheckBox.Text = "Byte#17";
            this.Byte17CheckBox.UseVisualStyleBackColor = true;
            this.Byte17CheckBox.CheckedChanged += new System.EventHandler(this.Byte17CheckBox_CheckedChanged);
            // 
            // Byte7CheckBox
            // 
            this.Byte7CheckBox.AutoSize = true;
            this.Byte7CheckBox.Enabled = false;
            this.Byte7CheckBox.Location = new System.Drawing.Point(173, 43);
            this.Byte7CheckBox.Name = "Byte7CheckBox";
            this.Byte7CheckBox.Size = new System.Drawing.Size(60, 17);
            this.Byte7CheckBox.TabIndex = 0;
            this.Byte7CheckBox.Text = "Byte#7";
            this.Byte7CheckBox.UseVisualStyleBackColor = true;
            this.Byte7CheckBox.CheckedChanged += new System.EventHandler(this.Byte7CheckBox_CheckedChanged);
            // 
            // Byte12CheckBox
            // 
            this.Byte12CheckBox.AutoSize = true;
            this.Byte12CheckBox.Enabled = false;
            this.Byte12CheckBox.Location = new System.Drawing.Point(339, 43);
            this.Byte12CheckBox.Name = "Byte12CheckBox";
            this.Byte12CheckBox.Size = new System.Drawing.Size(66, 17);
            this.Byte12CheckBox.TabIndex = 0;
            this.Byte12CheckBox.Text = "Byte#12";
            this.Byte12CheckBox.UseVisualStyleBackColor = true;
            this.Byte12CheckBox.CheckedChanged += new System.EventHandler(this.Byte12CheckBox_CheckedChanged);
            // 
            // Byte2CheckBox
            // 
            this.Byte2CheckBox.AutoSize = true;
            this.Byte2CheckBox.Enabled = false;
            this.Byte2CheckBox.Location = new System.Drawing.Point(6, 43);
            this.Byte2CheckBox.Name = "Byte2CheckBox";
            this.Byte2CheckBox.Size = new System.Drawing.Size(60, 17);
            this.Byte2CheckBox.TabIndex = 0;
            this.Byte2CheckBox.Text = "Byte#2";
            this.Byte2CheckBox.UseVisualStyleBackColor = true;
            this.Byte2CheckBox.CheckedChanged += new System.EventHandler(this.Byte2CheckBox_CheckedChanged);
            // 
            // Byte18ComboBox
            // 
            this.Byte18ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte18ComboBox.Enabled = false;
            this.Byte18ComboBox.FormattingEnabled = true;
            this.Byte18ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte18ComboBox.Location = new System.Drawing.Point(571, 68);
            this.Byte18ComboBox.Name = "Byte18ComboBox";
            this.Byte18ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte18ComboBox.TabIndex = 1;
            // 
            // Byte8ComboBox
            // 
            this.Byte8ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte8ComboBox.Enabled = false;
            this.Byte8ComboBox.FormattingEnabled = true;
            this.Byte8ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte8ComboBox.Location = new System.Drawing.Point(238, 68);
            this.Byte8ComboBox.Name = "Byte8ComboBox";
            this.Byte8ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte8ComboBox.TabIndex = 1;
            // 
            // Byte13ComboBox
            // 
            this.Byte13ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte13ComboBox.Enabled = false;
            this.Byte13ComboBox.FormattingEnabled = true;
            this.Byte13ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte13ComboBox.Location = new System.Drawing.Point(404, 68);
            this.Byte13ComboBox.Name = "Byte13ComboBox";
            this.Byte13ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte13ComboBox.TabIndex = 1;
            // 
            // Byte3ComboBox
            // 
            this.Byte3ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte3ComboBox.Enabled = false;
            this.Byte3ComboBox.FormattingEnabled = true;
            this.Byte3ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte3ComboBox.Location = new System.Drawing.Point(71, 68);
            this.Byte3ComboBox.Name = "Byte3ComboBox";
            this.Byte3ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte3ComboBox.TabIndex = 1;
            // 
            // Byte18CheckBox
            // 
            this.Byte18CheckBox.AutoSize = true;
            this.Byte18CheckBox.Enabled = false;
            this.Byte18CheckBox.Location = new System.Drawing.Point(506, 70);
            this.Byte18CheckBox.Name = "Byte18CheckBox";
            this.Byte18CheckBox.Size = new System.Drawing.Size(66, 17);
            this.Byte18CheckBox.TabIndex = 0;
            this.Byte18CheckBox.Text = "Byte#18";
            this.Byte18CheckBox.UseVisualStyleBackColor = true;
            this.Byte18CheckBox.CheckedChanged += new System.EventHandler(this.Byte18CheckBox_CheckedChanged);
            // 
            // Byte8CheckBox
            // 
            this.Byte8CheckBox.AutoSize = true;
            this.Byte8CheckBox.Enabled = false;
            this.Byte8CheckBox.Location = new System.Drawing.Point(173, 70);
            this.Byte8CheckBox.Name = "Byte8CheckBox";
            this.Byte8CheckBox.Size = new System.Drawing.Size(60, 17);
            this.Byte8CheckBox.TabIndex = 0;
            this.Byte8CheckBox.Text = "Byte#8";
            this.Byte8CheckBox.UseVisualStyleBackColor = true;
            this.Byte8CheckBox.CheckedChanged += new System.EventHandler(this.Byte8CheckBox_CheckedChanged);
            // 
            // Byte13CheckBox
            // 
            this.Byte13CheckBox.AutoSize = true;
            this.Byte13CheckBox.Enabled = false;
            this.Byte13CheckBox.Location = new System.Drawing.Point(339, 70);
            this.Byte13CheckBox.Name = "Byte13CheckBox";
            this.Byte13CheckBox.Size = new System.Drawing.Size(66, 17);
            this.Byte13CheckBox.TabIndex = 0;
            this.Byte13CheckBox.Text = "Byte#13";
            this.Byte13CheckBox.UseVisualStyleBackColor = true;
            this.Byte13CheckBox.CheckedChanged += new System.EventHandler(this.Byte13CheckBox_CheckedChanged);
            // 
            // Byte3CheckBox
            // 
            this.Byte3CheckBox.AutoSize = true;
            this.Byte3CheckBox.Enabled = false;
            this.Byte3CheckBox.Location = new System.Drawing.Point(6, 70);
            this.Byte3CheckBox.Name = "Byte3CheckBox";
            this.Byte3CheckBox.Size = new System.Drawing.Size(60, 17);
            this.Byte3CheckBox.TabIndex = 0;
            this.Byte3CheckBox.Text = "Byte#3";
            this.Byte3CheckBox.UseVisualStyleBackColor = true;
            this.Byte3CheckBox.CheckedChanged += new System.EventHandler(this.Byte3CheckBox_CheckedChanged);
            // 
            // Byte16ComboBox
            // 
            this.Byte16ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte16ComboBox.Enabled = false;
            this.Byte16ComboBox.FormattingEnabled = true;
            this.Byte16ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte16ComboBox.Location = new System.Drawing.Point(571, 14);
            this.Byte16ComboBox.Name = "Byte16ComboBox";
            this.Byte16ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte16ComboBox.TabIndex = 1;
            // 
            // Byte6ComboBox
            // 
            this.Byte6ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte6ComboBox.Enabled = false;
            this.Byte6ComboBox.FormattingEnabled = true;
            this.Byte6ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte6ComboBox.Location = new System.Drawing.Point(238, 14);
            this.Byte6ComboBox.Name = "Byte6ComboBox";
            this.Byte6ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte6ComboBox.TabIndex = 1;
            // 
            // Byte11ComboBox
            // 
            this.Byte11ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte11ComboBox.Enabled = false;
            this.Byte11ComboBox.FormattingEnabled = true;
            this.Byte11ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte11ComboBox.Location = new System.Drawing.Point(404, 14);
            this.Byte11ComboBox.Name = "Byte11ComboBox";
            this.Byte11ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte11ComboBox.TabIndex = 1;
            // 
            // Byte1ComboBox
            // 
            this.Byte1ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Byte1ComboBox.Enabled = false;
            this.Byte1ComboBox.FormattingEnabled = true;
            this.Byte1ComboBox.Items.AddRange(new object[] {
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<="});
            this.Byte1ComboBox.Location = new System.Drawing.Point(71, 14);
            this.Byte1ComboBox.Name = "Byte1ComboBox";
            this.Byte1ComboBox.Size = new System.Drawing.Size(42, 21);
            this.Byte1ComboBox.TabIndex = 1;
            // 
            // Byte16CheckBox
            // 
            this.Byte16CheckBox.AutoSize = true;
            this.Byte16CheckBox.Enabled = false;
            this.Byte16CheckBox.Location = new System.Drawing.Point(506, 16);
            this.Byte16CheckBox.Name = "Byte16CheckBox";
            this.Byte16CheckBox.Size = new System.Drawing.Size(66, 17);
            this.Byte16CheckBox.TabIndex = 0;
            this.Byte16CheckBox.Text = "Byte#16";
            this.Byte16CheckBox.UseVisualStyleBackColor = true;
            this.Byte16CheckBox.CheckedChanged += new System.EventHandler(this.Byte16CheckBox_CheckedChanged);
            // 
            // Byte6CheckBox
            // 
            this.Byte6CheckBox.AutoSize = true;
            this.Byte6CheckBox.Enabled = false;
            this.Byte6CheckBox.Location = new System.Drawing.Point(173, 16);
            this.Byte6CheckBox.Name = "Byte6CheckBox";
            this.Byte6CheckBox.Size = new System.Drawing.Size(60, 17);
            this.Byte6CheckBox.TabIndex = 0;
            this.Byte6CheckBox.Text = "Byte#6";
            this.Byte6CheckBox.UseVisualStyleBackColor = true;
            this.Byte6CheckBox.CheckedChanged += new System.EventHandler(this.Byte6CheckBox_CheckedChanged);
            // 
            // Byte11CheckBox
            // 
            this.Byte11CheckBox.AutoSize = true;
            this.Byte11CheckBox.Enabled = false;
            this.Byte11CheckBox.Location = new System.Drawing.Point(339, 16);
            this.Byte11CheckBox.Name = "Byte11CheckBox";
            this.Byte11CheckBox.Size = new System.Drawing.Size(66, 17);
            this.Byte11CheckBox.TabIndex = 0;
            this.Byte11CheckBox.Text = "Byte#11";
            this.Byte11CheckBox.UseVisualStyleBackColor = true;
            this.Byte11CheckBox.CheckedChanged += new System.EventHandler(this.Byte11CheckBox_CheckedChanged);
            // 
            // Byte1CheckBox
            // 
            this.Byte1CheckBox.AutoSize = true;
            this.Byte1CheckBox.Location = new System.Drawing.Point(6, 16);
            this.Byte1CheckBox.Name = "Byte1CheckBox";
            this.Byte1CheckBox.Size = new System.Drawing.Size(60, 17);
            this.Byte1CheckBox.TabIndex = 0;
            this.Byte1CheckBox.Text = "Byte#1";
            this.Byte1CheckBox.UseVisualStyleBackColor = true;
            this.Byte1CheckBox.CheckedChanged += new System.EventHandler(this.Byte1CheckBox_CheckedChanged);
            // 
            // Param2HexadecimalTextBox
            // 
            this.Param2HexadecimalTextBox.Delimiter = "";
            this.Param2HexadecimalTextBox.Enabled = false;
            this.Param2HexadecimalTextBox.Location = new System.Drawing.Point(325, 81);
            this.Param2HexadecimalTextBox.MaxLength = 2;
            this.Param2HexadecimalTextBox.Name = "Param2HexadecimalTextBox";
            this.Param2HexadecimalTextBox.Size = new System.Drawing.Size(100, 20);
            this.Param2HexadecimalTextBox.TabIndex = 5;
            this.Param2HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Param1HexadecimalTextBox
            // 
            this.Param1HexadecimalTextBox.Delimiter = "";
            this.Param1HexadecimalTextBox.Enabled = false;
            this.Param1HexadecimalTextBox.Location = new System.Drawing.Point(325, 55);
            this.Param1HexadecimalTextBox.MaxLength = 2;
            this.Param1HexadecimalTextBox.Name = "Param1HexadecimalTextBox";
            this.Param1HexadecimalTextBox.Size = new System.Drawing.Size(100, 20);
            this.Param1HexadecimalTextBox.TabIndex = 5;
            this.Param1HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // CMDHexadecimalTextBox
            // 
            this.CMDHexadecimalTextBox.Delimiter = "";
            this.CMDHexadecimalTextBox.Location = new System.Drawing.Point(325, 29);
            this.CMDHexadecimalTextBox.MaxLength = 2;
            this.CMDHexadecimalTextBox.Name = "CMDHexadecimalTextBox";
            this.CMDHexadecimalTextBox.Size = new System.Drawing.Size(100, 20);
            this.CMDHexadecimalTextBox.TabIndex = 5;
            this.CMDHexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte20HexadecimalTextBox
            // 
            this.Byte20HexadecimalTextBox.Delimiter = "";
            this.Byte20HexadecimalTextBox.Enabled = false;
            this.Byte20HexadecimalTextBox.Location = new System.Drawing.Point(619, 122);
            this.Byte20HexadecimalTextBox.MaxLength = 2;
            this.Byte20HexadecimalTextBox.Name = "Byte20HexadecimalTextBox";
            this.Byte20HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte20HexadecimalTextBox.TabIndex = 2;
            this.Byte20HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte10HexadecimalTextBox
            // 
            this.Byte10HexadecimalTextBox.Delimiter = "";
            this.Byte10HexadecimalTextBox.Enabled = false;
            this.Byte10HexadecimalTextBox.Location = new System.Drawing.Point(286, 122);
            this.Byte10HexadecimalTextBox.MaxLength = 2;
            this.Byte10HexadecimalTextBox.Name = "Byte10HexadecimalTextBox";
            this.Byte10HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte10HexadecimalTextBox.TabIndex = 2;
            this.Byte10HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte15HexadecimalTextBox
            // 
            this.Byte15HexadecimalTextBox.Delimiter = "";
            this.Byte15HexadecimalTextBox.Enabled = false;
            this.Byte15HexadecimalTextBox.Location = new System.Drawing.Point(452, 122);
            this.Byte15HexadecimalTextBox.MaxLength = 2;
            this.Byte15HexadecimalTextBox.Name = "Byte15HexadecimalTextBox";
            this.Byte15HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte15HexadecimalTextBox.TabIndex = 2;
            this.Byte15HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte5HexadecimalTextBox
            // 
            this.Byte5HexadecimalTextBox.Delimiter = "";
            this.Byte5HexadecimalTextBox.Enabled = false;
            this.Byte5HexadecimalTextBox.Location = new System.Drawing.Point(119, 122);
            this.Byte5HexadecimalTextBox.MaxLength = 2;
            this.Byte5HexadecimalTextBox.Name = "Byte5HexadecimalTextBox";
            this.Byte5HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte5HexadecimalTextBox.TabIndex = 2;
            this.Byte5HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte19HexadecimalTextBox
            // 
            this.Byte19HexadecimalTextBox.Delimiter = "";
            this.Byte19HexadecimalTextBox.Enabled = false;
            this.Byte19HexadecimalTextBox.Location = new System.Drawing.Point(619, 95);
            this.Byte19HexadecimalTextBox.MaxLength = 2;
            this.Byte19HexadecimalTextBox.Name = "Byte19HexadecimalTextBox";
            this.Byte19HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte19HexadecimalTextBox.TabIndex = 2;
            this.Byte19HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte9HexadecimalTextBox
            // 
            this.Byte9HexadecimalTextBox.Delimiter = "";
            this.Byte9HexadecimalTextBox.Enabled = false;
            this.Byte9HexadecimalTextBox.Location = new System.Drawing.Point(286, 95);
            this.Byte9HexadecimalTextBox.MaxLength = 2;
            this.Byte9HexadecimalTextBox.Name = "Byte9HexadecimalTextBox";
            this.Byte9HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte9HexadecimalTextBox.TabIndex = 2;
            this.Byte9HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte14HexadecimalTextBox
            // 
            this.Byte14HexadecimalTextBox.Delimiter = "";
            this.Byte14HexadecimalTextBox.Enabled = false;
            this.Byte14HexadecimalTextBox.Location = new System.Drawing.Point(452, 95);
            this.Byte14HexadecimalTextBox.MaxLength = 2;
            this.Byte14HexadecimalTextBox.Name = "Byte14HexadecimalTextBox";
            this.Byte14HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte14HexadecimalTextBox.TabIndex = 2;
            this.Byte14HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte4HexadecimalTextBox
            // 
            this.Byte4HexadecimalTextBox.Delimiter = "";
            this.Byte4HexadecimalTextBox.Enabled = false;
            this.Byte4HexadecimalTextBox.Location = new System.Drawing.Point(119, 95);
            this.Byte4HexadecimalTextBox.MaxLength = 2;
            this.Byte4HexadecimalTextBox.Name = "Byte4HexadecimalTextBox";
            this.Byte4HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte4HexadecimalTextBox.TabIndex = 2;
            this.Byte4HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte17HexadecimalTextBox
            // 
            this.Byte17HexadecimalTextBox.Delimiter = "";
            this.Byte17HexadecimalTextBox.Enabled = false;
            this.Byte17HexadecimalTextBox.Location = new System.Drawing.Point(619, 41);
            this.Byte17HexadecimalTextBox.MaxLength = 2;
            this.Byte17HexadecimalTextBox.Name = "Byte17HexadecimalTextBox";
            this.Byte17HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte17HexadecimalTextBox.TabIndex = 2;
            this.Byte17HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte7HexadecimalTextBox
            // 
            this.Byte7HexadecimalTextBox.Delimiter = "";
            this.Byte7HexadecimalTextBox.Enabled = false;
            this.Byte7HexadecimalTextBox.Location = new System.Drawing.Point(286, 41);
            this.Byte7HexadecimalTextBox.MaxLength = 2;
            this.Byte7HexadecimalTextBox.Name = "Byte7HexadecimalTextBox";
            this.Byte7HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte7HexadecimalTextBox.TabIndex = 2;
            this.Byte7HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte12HexadecimalTextBox
            // 
            this.Byte12HexadecimalTextBox.Delimiter = "";
            this.Byte12HexadecimalTextBox.Enabled = false;
            this.Byte12HexadecimalTextBox.Location = new System.Drawing.Point(452, 41);
            this.Byte12HexadecimalTextBox.MaxLength = 2;
            this.Byte12HexadecimalTextBox.Name = "Byte12HexadecimalTextBox";
            this.Byte12HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte12HexadecimalTextBox.TabIndex = 2;
            this.Byte12HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte2HexadecimalTextBox
            // 
            this.Byte2HexadecimalTextBox.Delimiter = "";
            this.Byte2HexadecimalTextBox.Enabled = false;
            this.Byte2HexadecimalTextBox.Location = new System.Drawing.Point(119, 41);
            this.Byte2HexadecimalTextBox.MaxLength = 2;
            this.Byte2HexadecimalTextBox.Name = "Byte2HexadecimalTextBox";
            this.Byte2HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte2HexadecimalTextBox.TabIndex = 2;
            this.Byte2HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte18HexadecimalTextBox
            // 
            this.Byte18HexadecimalTextBox.Delimiter = "";
            this.Byte18HexadecimalTextBox.Enabled = false;
            this.Byte18HexadecimalTextBox.Location = new System.Drawing.Point(619, 68);
            this.Byte18HexadecimalTextBox.MaxLength = 2;
            this.Byte18HexadecimalTextBox.Name = "Byte18HexadecimalTextBox";
            this.Byte18HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte18HexadecimalTextBox.TabIndex = 2;
            this.Byte18HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte8HexadecimalTextBox
            // 
            this.Byte8HexadecimalTextBox.Delimiter = "";
            this.Byte8HexadecimalTextBox.Enabled = false;
            this.Byte8HexadecimalTextBox.Location = new System.Drawing.Point(286, 68);
            this.Byte8HexadecimalTextBox.MaxLength = 2;
            this.Byte8HexadecimalTextBox.Name = "Byte8HexadecimalTextBox";
            this.Byte8HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte8HexadecimalTextBox.TabIndex = 2;
            this.Byte8HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte13HexadecimalTextBox
            // 
            this.Byte13HexadecimalTextBox.Delimiter = "";
            this.Byte13HexadecimalTextBox.Enabled = false;
            this.Byte13HexadecimalTextBox.Location = new System.Drawing.Point(452, 68);
            this.Byte13HexadecimalTextBox.MaxLength = 2;
            this.Byte13HexadecimalTextBox.Name = "Byte13HexadecimalTextBox";
            this.Byte13HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte13HexadecimalTextBox.TabIndex = 2;
            this.Byte13HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte3HexadecimalTextBox
            // 
            this.Byte3HexadecimalTextBox.Delimiter = "";
            this.Byte3HexadecimalTextBox.Enabled = false;
            this.Byte3HexadecimalTextBox.Location = new System.Drawing.Point(119, 68);
            this.Byte3HexadecimalTextBox.MaxLength = 2;
            this.Byte3HexadecimalTextBox.Name = "Byte3HexadecimalTextBox";
            this.Byte3HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte3HexadecimalTextBox.TabIndex = 2;
            this.Byte3HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte16HexadecimalTextBox
            // 
            this.Byte16HexadecimalTextBox.Delimiter = "";
            this.Byte16HexadecimalTextBox.Enabled = false;
            this.Byte16HexadecimalTextBox.Location = new System.Drawing.Point(619, 14);
            this.Byte16HexadecimalTextBox.MaxLength = 2;
            this.Byte16HexadecimalTextBox.Name = "Byte16HexadecimalTextBox";
            this.Byte16HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte16HexadecimalTextBox.TabIndex = 2;
            this.Byte16HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte6HexadecimalTextBox
            // 
            this.Byte6HexadecimalTextBox.Delimiter = "";
            this.Byte6HexadecimalTextBox.Enabled = false;
            this.Byte6HexadecimalTextBox.Location = new System.Drawing.Point(286, 14);
            this.Byte6HexadecimalTextBox.MaxLength = 2;
            this.Byte6HexadecimalTextBox.Name = "Byte6HexadecimalTextBox";
            this.Byte6HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte6HexadecimalTextBox.TabIndex = 2;
            this.Byte6HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte11HexadecimalTextBox
            // 
            this.Byte11HexadecimalTextBox.Delimiter = "";
            this.Byte11HexadecimalTextBox.Enabled = false;
            this.Byte11HexadecimalTextBox.Location = new System.Drawing.Point(452, 14);
            this.Byte11HexadecimalTextBox.MaxLength = 2;
            this.Byte11HexadecimalTextBox.Name = "Byte11HexadecimalTextBox";
            this.Byte11HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte11HexadecimalTextBox.TabIndex = 2;
            this.Byte11HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Byte1HexadecimalTextBox
            // 
            this.Byte1HexadecimalTextBox.Delimiter = "";
            this.Byte1HexadecimalTextBox.Enabled = false;
            this.Byte1HexadecimalTextBox.Location = new System.Drawing.Point(119, 14);
            this.Byte1HexadecimalTextBox.MaxLength = 2;
            this.Byte1HexadecimalTextBox.Name = "Byte1HexadecimalTextBox";
            this.Byte1HexadecimalTextBox.Size = new System.Drawing.Size(28, 20);
            this.Byte1HexadecimalTextBox.TabIndex = 2;
            this.Byte1HexadecimalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MTKTestCUSDialog
            // 
            this.AcceptButton = this.OKButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.CloseButton;
            this.ClientSize = new System.Drawing.Size(692, 262);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.NameTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.OKButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MTKTestCUSDialog";
            this.Text = "Custom Test";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CMDDelayNumericUpDown)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button OKButton;
        private System.Windows.Forms.Button CloseButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox NameTextBox;
        private System.Windows.Forms.Label label2;
        private HexadecimalTextBoxControl.HexadecimalTextBox CMDHexadecimalTextBox;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private HexadecimalTextBoxControl.HexadecimalTextBox Param1HexadecimalTextBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Param2HexadecimalTextBox;
        private System.Windows.Forms.CheckBox Param1CheckBox;
        private System.Windows.Forms.CheckBox Param2CheckBox;
        private System.Windows.Forms.CheckBox Byte1CheckBox;
        private System.Windows.Forms.ComboBox Byte1ComboBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte1HexadecimalTextBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte2HexadecimalTextBox;
        private System.Windows.Forms.ComboBox Byte2ComboBox;
        private System.Windows.Forms.CheckBox Byte2CheckBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte4HexadecimalTextBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte3HexadecimalTextBox;
        private System.Windows.Forms.ComboBox Byte4ComboBox;
        private System.Windows.Forms.CheckBox Byte4CheckBox;
        private System.Windows.Forms.ComboBox Byte3ComboBox;
        private System.Windows.Forms.CheckBox Byte3CheckBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte5HexadecimalTextBox;
        private System.Windows.Forms.ComboBox Byte5ComboBox;
        private System.Windows.Forms.CheckBox Byte5CheckBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte10HexadecimalTextBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte9HexadecimalTextBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte7HexadecimalTextBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte8HexadecimalTextBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte6HexadecimalTextBox;
        private System.Windows.Forms.ComboBox Byte10ComboBox;
        private System.Windows.Forms.ComboBox Byte9ComboBox;
        private System.Windows.Forms.CheckBox Byte10CheckBox;
        private System.Windows.Forms.ComboBox Byte7ComboBox;
        private System.Windows.Forms.CheckBox Byte9CheckBox;
        private System.Windows.Forms.CheckBox Byte7CheckBox;
        private System.Windows.Forms.ComboBox Byte8ComboBox;
        private System.Windows.Forms.CheckBox Byte8CheckBox;
        private System.Windows.Forms.ComboBox Byte6ComboBox;
        private System.Windows.Forms.CheckBox Byte6CheckBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte20HexadecimalTextBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte15HexadecimalTextBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte19HexadecimalTextBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte14HexadecimalTextBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte17HexadecimalTextBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte12HexadecimalTextBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte18HexadecimalTextBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte13HexadecimalTextBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte16HexadecimalTextBox;
        private HexadecimalTextBoxControl.HexadecimalTextBox Byte11HexadecimalTextBox;
        private System.Windows.Forms.ComboBox Byte20ComboBox;
        private System.Windows.Forms.ComboBox Byte15ComboBox;
        private System.Windows.Forms.ComboBox Byte19ComboBox;
        private System.Windows.Forms.ComboBox Byte14ComboBox;
        private System.Windows.Forms.CheckBox Byte20CheckBox;
        private System.Windows.Forms.CheckBox Byte15CheckBox;
        private System.Windows.Forms.ComboBox Byte17ComboBox;
        private System.Windows.Forms.ComboBox Byte12ComboBox;
        private System.Windows.Forms.CheckBox Byte19CheckBox;
        private System.Windows.Forms.CheckBox Byte14CheckBox;
        private System.Windows.Forms.CheckBox Byte17CheckBox;
        private System.Windows.Forms.CheckBox Byte12CheckBox;
        private System.Windows.Forms.ComboBox Byte18ComboBox;
        private System.Windows.Forms.ComboBox Byte13ComboBox;
        private System.Windows.Forms.CheckBox Byte18CheckBox;
        private System.Windows.Forms.CheckBox Byte13CheckBox;
        private System.Windows.Forms.ComboBox Byte16ComboBox;
        private System.Windows.Forms.ComboBox Byte11ComboBox;
        private System.Windows.Forms.CheckBox Byte16CheckBox;
        private System.Windows.Forms.CheckBox Byte11CheckBox;
        private System.Windows.Forms.NumericUpDown CMDDelayNumericUpDown;
        private System.Windows.Forms.Label label3;
    }
}