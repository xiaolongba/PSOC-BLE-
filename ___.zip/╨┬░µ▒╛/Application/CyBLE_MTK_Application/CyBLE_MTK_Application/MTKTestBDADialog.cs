﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CyBLE_MTK_Application
{
    public partial class MTKTestBDADialog : Form
    {
        private MTKTestBDA BDAProg;

        public MTKTestBDADialog()
        {
            InitializeComponent();
            BDAProg = new MTKTestBDA();
        }

        public MTKTestBDADialog(MTKTestBDA BDAProgrammer) : this()
        {
            BDAProg = BDAProgrammer;
            BDATextBox.SetTextFromByteArray(BDAProg.BDAddress);
            AddressPublicCheckBox.Checked = BDAProg.PublicBDA;
            AutoIncrementCheckBox.Checked = BDAProg.AutoIncrementBDA;
            ProgrammerInfoLabel.Text = BDAProg.BDAProgrammer.GetDisplayText();
        }

        private void OKButton_Click(object sender, EventArgs e)
        {
            for (int i = BDATextBox.GetTextWithoutDelimiters().Length; i < 12; i++)
            {
                BDATextBox.Text += "0";
            }

            BDAProg.BDAddress = BDATextBox.ToByteArray();
            BDAProg.PublicBDA = AddressPublicCheckBox.Checked;
            BDAProg.AutoIncrementBDA = AutoIncrementCheckBox.Checked;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void ProgrammerConfigButton_Click(object sender, EventArgs e)
        {
            if (!BDAProg.BDAProgrammer.PSoCProgrammerInstalled || !BDAProg.BDAProgrammer.IsCorrectVersion())
            {
                return;
            }

            MTKPSoCProgrammerDialog TempDialog = new MTKPSoCProgrammerDialog(BDAProg.BDAProgrammer);
            TempDialog.SetupForBDA();

            if (TempDialog.ShowDialog() == DialogResult.OK)
            {
                ProgrammerInfoLabel.Text = BDAProg.BDAProgrammer.GetDisplayText();
            }
        }
    }
}
